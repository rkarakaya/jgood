/**
 * @author Ramazan Karakaya
 */

(function () {
    "use strict";
    var jgood = angular.module('jgood',
        [
            'ui.router',
            'ngSanitize',
            'ui.bootstrap',
            'ui.validate',
            'ngAnimate',
            'ngStorage',
            'angular-fn',
            'ngStorage'
        ]);


    (function (core, coreFactory) {

        // Controllers will be defined by dot-delimited namespaces
        // that end in "Ctrl" (ex. foo.BarCtrl).
        var pattern = /\.[^.]*?Ctrl$/i;

        // As the factories are invoked, each will return the
        // constructor for the given Controller; we can cache these
        // so we don't have to keep re-wiring the factories.
        var constructors = {};

        // I proxy the core factory and route the request to either
        // the Controller provider or the underlying factory.
        function factory(name, controllerFactory) {

            // If the given injectable name is not one of our
            // factories, then just hand it off to the core
            // factory registration.
            if (!pattern.test(name)) {
                return coreFactory.apply(core, arguments);
            }

            // Register the Controller Factory method as a
            // Controller. Here, we will leverage the fact that
            // the *RETURN* value of the constructor is what is
            // actually being used as the Controller instance.
            core.controller(
                name,
                function ($scope, $injector) {

                    var cacheKey = "cache_" + name;

                    var Constructor = constructors[cacheKey];

                    // If the cached constructor hasn't been built
                    // yet, invoke the factory and cache the
                    // constructor for later use.
                    if (!Constructor) {
                        Constructor = constructors[cacheKey] = $injector.invoke(controllerFactory);
                    }

                    // By returning something other than _this_,
                    // we are telling AngularJS to use the following
                    // object instance as the Controller instead of
                    // the of the current context (ie, the Factory).
                    // --
                    // NOTE: We have to pass $scope through as an
                    // injectable otherwise the Dependency-Injection
                    // framework will not know how to create it.
                    return $injector.instantiate(Constructor, {"$scope": $scope});

                }
            );

            // Return the core to continue method chaining.
            return core;

        }

        // Overwrite the Angular-provided factory.
        core.factory = factory;

    }(jgood, jgood.factory));

}());



/**
 * global util functions
 * @author Ramazan Karakaya
 */


_.arrayToMap = function (arr, keyProperty, options) {
    options = options || {mode: 'override'};
    var
        retMap = {}, modeOverride = options.mode == 'override';
    if (arr) {
        var target = arr.$$v || arr;
        _.each(target, function (item) {
            var propName = item[keyProperty];
            var value = options.valueProperty ? item[options.valueProperty] : item;
            if (propName != '$$hashKey') {
                if (modeOverride) {
                    retMap[propName] = value;
                } else {
                    retMap[propName] = retMap[propName] || [];
                    retMap[propName].push(value);
                }
            }
        });
    }
    return retMap;
}
_.mapToArray = function (map, keyPropertyName) {
    var retArr = [];
    if (map) {
        var target = map.$$v || map;
        _.each(target, function (val, key) {
            var item = {};
            item[keyPropertyName] = key;
            _.extend(item, val);
            retArr.push(item);

        });
    }
    return retArr;
}

_.getPropertyByArrayPath = function (object, arrPath) {
    var result = object;

    for (var i = 0; i < arrPath.length; i++) {
        result = result[arrPath[i]];
    }

    return result;
}

_.getPropertyByStrPath = function (object, strPath) {
    return _.getPropertyByArrayPath(object, strPath.split('.'));
}

_.addOrReplaceArray = function (arr, newValue, propPath) {
    var
        srcArr = arr || [],
        target = srcArr.$$v || srcArr,
        len = target.length,
        propNames = _.isArray(propPath) ? propPath : [propPath] , propPaths = [];

    for (var i = 0; i < propNames.length; i++) {
        propPaths.push(propNames[i].split('.'));
    }

    var leftVal, rightVal;

    for (i = 0; i < len; i++) {
        var equal = true;
        for (var j = 0; j < propPaths.length; j++) {
            leftVal = _.getPropertyByArrayPath(target[i], propPaths[j]);
            rightVal = _.getPropertyByArrayPath(newValue, propPaths[j]);
            if (leftVal != rightVal) {
                equal = false;
                break;
            }
        }

        if (equal) {
            return target.splice(i, 1, newValue);
        }
    }
    target.push(newValue);
}
_.findByProperty = function (collection, property, value) {
    if (!collection) {
        return null;
    }

    var
        target = collection.$$v || collection
        , len = target.length
        , arrPath = property.split('.');

    for (var i = 0; i < len; i++) {
        if (_.getPropertyByArrayPath(target[i], arrPath) == value) {
            return target[i];
        }
    }
    return null;
}

_.indexOfByProperty = function (collection, property, value) {
    if (!collection) {
        return -1;
    }

    var
        target = collection.$$v || collection
        , len = target.length
        , arrPath = property.split('.');

    for (var i = 0; i < len; i++) {
        if (_.getPropertyByArrayPath(target[i], arrPath) == value) {
            return i;
        }
    }
    return -1;
}

_.findByPropertyExample = function (collection, example) {
    if (collection) {
        var target = collection.$$v || collection;
        var resultArray = _.where(target, example);
        return resultArray.length > 0 ? resultArray[0] : null;
    }
    return null;
}

_.containsObjectByProp = function (collection, property, value) {
    if (collection) {
        var obj = _.findByProperty(collection, property, value);
        return obj !== null;
    }
    return false;
}
_.containsObjectOtherThanByProperty = function (collection, item, propName) {
    var obj = _.findByProperty(collection, propName, item[propName]);
    if (obj) {
        return obj != item;
    }
    return false;
}

_.notContainsObjectByProp = function (collection, property, value) {
    if (collection) {
        var obj = _.findByProperty(collection, property, value);
        return obj == null;
    }
    return true;
}

_.removeByProperty = function (collection, property, search) {
    if (collection) {
        var
            target = collection.$$v || collection
            , arrPath = property.split('.');
        if (_.isArray(target)) {
            var len = target.length;
            var indexArr = [];
            for (var i = 0; i < len; i++) {
                if (_.getPropertyByArrayPath(target[i], arrPath) == search) {
                    indexArr.push(i);
                }
            }
            if (indexArr.length > 0) {
                for (var i = 0; i < indexArr.length; i++) {
                    target.splice(indexArr[i] - i, 1);
                }
            }
        } else if (_.isObject(target)) {
            _.forEach(target, function (value, key) {
                if (value && _.getPropertyByArrayPath(value, arrPath) == search) {
                    delete target[key];
                }
            });
        }
    }
}

_.removeByExample = function (collection, example) {
    if (collection) {
        var
            target = collection.$$v || collection
            , exWithPaths = []
            ;

        for (var p in example) {
            exWithPaths.push({
                path: p.split('.'),
                val: example[p]
            });
        }

        if (_.isArray(target)) {
            var len = target.length;
            var indexArr = [];
            for (var i = 0; i < len; i++) {
                var equal = true;

                for (var k = 0; k < exWithPaths.length; k++) {
                    if (_.getPropertyByArrayPath(target[i], exWithPaths[k].path) != exWithPaths[k].val) {
                        equal = false;
                        break;
                    }
                }

                if (equal) {
                    indexArr.push(i);
                }

            }
            if (indexArr.length > 0) {
                for (var i = 0; i < indexArr.length; i++) {
                    target.splice(indexArr[i] - i, 1);
                }
            }
        } else if (_.isObject(target)) {
            _.forEach(target, function (key, val) {
                if (_.isObject(val)) {
                    var equal = true;
                    for (var p in example) {
                        if (val[p] != example[p]) {
                            equal = false;
                            break;
                        }
                    }
                    if (equal) {
                        delete target[key];
                    }
                }
            });
        }
    }
}

_.isNotEmpty = function (obj) {
    if (obj) {
        var target = obj.$$v || obj;
        return _.isEmpty(target) == false;
    }
    return false;
}

_.valuesFirst = function (obj) {
    var target = obj.$$v || obj;
    for (var key in target) {
        if (_.str.startsWith(key, '$') == false && _.has(target, key)) {
            return target[key];
        }
    }

    return  null;
}

_.keysFirst = function (obj) {
    if (obj) {
        var target = obj.$$v || obj;
        var keyArr = _.keys(target);
        return keyArr.length > 0 ? keyArr[0] : null;
    }
    return null;
}

_.pushAll = function (dstArray, srcArray) {
    var src = srcArray.$$v || srcArray;
    _.forEach(src, function (item) {
        dstArray.push(item);
    });
}

_.isNumeric = function (obj) {
    return !isNaN(parseFloat(obj)) && isFinite(obj);
}
_.str.substrAfterNumeric = function (str) {
    if (str) {
        var k = 0;
        for (; k < str.length; k++) {
            if (str.charAt(k) != '.' && isNaN(str.charAt(k))) {
                break;
            }
        }
        if (k < str.length) {
            return str.substr(k);
        }
    }
    return '';
}
_.str.substrBeforeAlpha = function (str) {
    var retStr = '';
    if (str) {
        var k = 0;
        for (; k < str.length; k++) {
            if (str.charAt(k) == '.' || !isNaN(str.charAt(k))) {
                retStr += str.charAt(k);
            } else {
                break;
            }
        }
    }
    return retStr;
}


_.removeFromSet = function (sourceArray, itemToBeRemoved) {
    var index = _.indexOf(sourceArray, itemToBeRemoved);
    if (index !== -1) {
        sourceArray.splice(index, 1);
    }
}

_.removeFromStringSet = function (obj, property, strRemove) {
    var str = obj[property];
    if (str) {
        var arr = str.split(',');
        obj[property] = _.without(arr, strRemove).join(',');
    }
}

_.addToStringSet = function (obj, property, strAdd) {
    var str = obj[property];
    if (str) {
        var arr = str.split(',');
        if (_.contains(arr, strAdd) == false) {
            obj[property] = str + ',' + strAdd;
        }
    } else {
        obj[property] = strAdd;
    }
}

_.addToSet = function (sourceArray, itemToBeAdd) {
    if (_.isNotEmpty(itemToBeAdd)) {
        var index = _.indexOf(sourceArray, itemToBeAdd);
        if (index == -1) {
            sourceArray.push(itemToBeAdd);
            return true;
        }
    }
    return false;
}
_.overrideObject = function (target, source) {
    for (var p in target) {
        if (_.isUndefined(source[p]) == false) {
            target[p] = source[p];
        }
    }
}

_.copyDefaults = function (target, defaults) {
    for (var p in defaults) {
        if (_.isUndefined(target[p])) {
            target[p] = defaults[p];
        }
    }
}

_.ensureObjectsByPath = function (obj, path) {
    var arr = path.split('.');
    var objRef = obj;
    for (var i = 0; i < arr.length; i++) {
        objRef[arr[i]] = objRef[arr[i]] || {};
        objRef = objRef[arr[i]];
    }
}

_.cleanEmptyProperties = function (obj) {
    if (_.isObject(obj)) {
        _.forEach(obj, function (val, key) {
            if (val == null) {
                delete obj[key];
            } else if (_.isArray(val)) {
                if (!val.length) {
                    delete obj[key];
                }
                //do nothing
            } else if (_.isNumber(val) || _.isBoolean(val)) {
                //do nothing
            } else if (_.isObject(val)) {
                _.cleanEmptyProperties(val);
            } else if (_.isEmpty(val)) {
                delete obj[key];
            }
        });
    }
}

_.innerObject = function (obj) {
    var innerObj = null;
    if (_.isObject(obj)) {
        _.forEach(obj, function (innerVal, innerKey) {
            if (_.isObject(innerVal)) {
                innerObj = innerVal;
            }
        });
    }
    return innerObj;
}


_.deleteProperties = function (obj, propArray) {
    _.forEach(propArray, function (propName) {
        delete obj[propName];
    });
}

_.leafKeysRecursive = function (rootObj) {
    var leafPaths = [];

    function traverse(obj, path) {

        _.forEach(obj, function (value, key) {
            if (_.isObject(value)) {
                var innerPath = [].concat(path);
                innerPath.push(key);
                traverse(value, innerPath);
            } else {
                if (path.length) {
                    leafPaths.push(path.join('.') + '.' + key);
                } else {
                    leafPaths.push(key);
                }
            }
        });
    }

    traverse(rootObj, []);
    return leafPaths;
}

_.deletePropertiesPrefixedBy = function (obj, prefix) {
    _.forEach(obj, function (value, key) {
        if (_.isObject(value)) {
            _.deletePropertiesPrefixedBy(value, prefix);
        } else if (_.str.startsWith(key, prefix)) {
            delete obj[key];
        }
    });

}


_.elementById = function (id) {
    var elm = angular.element(document.querySelector('#' + id));
    return elm;
}
/**
 * @author Ramazan Karakaya
 */

(function () {
    function jgRowLayoutDirective() {
        return {
            priority: 9999,
            restrict: 'A',
            compile: function compile(tElement, tAttrs, transclude) {

                return {
                    pre: function (scope, element, attrs) {
                        var layoutStr = attrs.jgRowLayout;
                        if (layoutStr) {
                            element.data('jgRowLayout', layoutStr);
                        }
                    }
                };
            }
        };
    }

    jgRowLayoutDirective.$inject = [];
    angular.module('jgood').directive('jgRowLayout', jgRowLayoutDirective);
}());


(function () {
    function jgFormGroupDirective(textsService, $compile, $interpolate) {
        return {
            restrict: 'EA',
            templateUrl: function (tElement, tAttrs) {
                var as = ['app/common/directive/partial/formGroup'];
                if (tAttrs.jqpTplSuffix) {
                    as.push('_');
                    as.push(tAttrs.jgpTplSuffix);
                }
                as.push('.html');
                return as.join('');
            },

            replace: true,
            transclude: true,
            require: '^form',
            scope: {
                labelKey: '@jgFormGroup',
                jgpHelpSuffix: '='
            },
            controller: ['$scope', '$element', '$transclude',
                function ($scope, $element, $transclude) {
                    $transclude(function (clone) {
                        var $controlBlock = $element.find('.tc');
                        $controlBlock.prepend(clone);

                        var errorElm = angular.element('<span class="help-inline">{{errorTipMessage}}</span>');

                        $controlBlock.append(errorElm);
                        $compile(errorElm)($scope);
                    });
                }],

            link: function (scope, element, attrs, formCtrl) {
                var formName = element.closest('[ng-form]').attr('ng-form') || element.closest('form').attr('name'),
                    elmInput = element.find('[ng-model]'),
                    remaining;

                if (!elmInput.is(':checkbox') && !elmInput.is(':hidden') && !elmInput.is(':radio')) {
                    elmInput.addClass('form-control');
                }

                var rowLayoutStr = element.inheritedData('jqRowLayout');
                if (rowLayoutStr) {
                    rowLayoutStr = "''" + rowLayoutStr;
                } else {
                    rowLayoutStr = '1:2:9';
                }
                var arrCells = rowLayoutStr.split(':');

                scope.labelColClass = 'col-md-' + arrCells[0];

                remaining = 12 - (arrCells[0] * 1);

                if (arrCells.length > 1) {
                    scope.controlColClass = 'col-md-' + (arrCells[1]);
                    remaining -= (arrCells[1] * 1);
                } else {
                    scope.controlColClass = 'col-md-' + Math.floor(remaining * 0.25);
                    scope.helpColClass = 'col-md-' + Math.floor(remaining * 0.58);
                }

                if (arrCells.length > 2) {
                    scope.helpColClass = 'col-md-' + remaining;
                }

                var helpKeyDefault = attrs.jgpHelpKey || (scope.labelKey + '_h'),
                    helpMessageDefault = textsService.translate(helpKeyDefault);
                scope.helpMessage = helpMessageDefault;
                scope.$watch('jgpHelpSuffix', function (suffix) {
                    var msg;
                    if (suffix) {
                        msg = textsService.translate(helpKeyDefault + '_' + suffix);
                    }
                    scope.helpMessage = msg || helpMessageDefault;
                });

                if (formName && elmInput.length) {

                    var inputName = elmInput.attr('name');
                    if (inputName) {
                        inputName = $interpolate(inputName)(scope.$parent);

                        var validateDef = scope.$eval(elmInput.attr('ui-validate') || '{}');
                        var validationKeys = _.keys(validateDef);
                        _.addToSet(validationKeys, 'required');
                        var errorMsgMap = {};
                        _.forEach(validationKeys, function (key) {
                            errorMsgMap[key] = textsService.translate([formName, 'error', inputName, key].join('.'))
                                || textsService.translate(['error', inputName, key].join('.'))
                                || textsService.translate('general.error.' + key);
                        });


                        var errorExpression = [formName, inputName, "$invalid"].join(".");
                        // Watch the parent scope, because current scope is isolated.
                        scope.$parent.$watch(errorExpression, function (isError) {

                            scope.isError = isError;
                            var errMsg = '';
                            if (isError) {
                                var errors = [];
                                _.forEach(validationKeys, function (validationKey) {
                                    if (formCtrl.$error[validationKey]) {
                                        errors.push(errorMsgMap[validationKey]);
                                    }
                                });
                                errMsg = errors.join(',');
                            }
                            scope.errorTipMessage = errMsg;

                        });
                    }
                }
            }
        };
    }

    jgFormGroupDirective.$inject = ['jg.textsService', '$compile', '$interpolate'];
    angular.module('jgood').directive('jgFormGroup', jgFormGroupDirective);
}());


/**
 * @author Ramazan Karakaya
 */

(function () {
    function textFilter(textsService) {
        return function () {
            return textsService.translateSafe.apply(this, arguments);
        };
    }

    textFilter.$inject = ['jg.textsService'];
    angular.module('jgood').filter('text', textFilter);
}());



/**
 * securityInterceptor - check security related HTTP status messages and redirect.
 *
 * @author Ramazan Karakaya
 */
(function () {
    var MSG_NOT_ALLOWED = "You are not allowed to perform this action!";

    function securityInterceptor($q, $log, $injector, $rootScope) {
        var $state;

        function goToLogin() {
            if (!$state) {
                $state = $injector.get('$state');
            }

            $rootScope.afterLogin = {};
            $rootScope.afterLogin.toState = $state.next;
            $rootScope.afterLogin.toParams = $state.toParams;

            $state.go('login');
        }

        return {
            requestError: function (rejection) {
                return $q.reject(rejection);
            },

            // optional method
            response: function (response) {
                return response || $q.when(response);
            },

            responseError: function (rejection) {
                if (rejection.status === 401) {
                    goToLogin();
                } else if (rejection.status === 403) {
                    rejection.data = rejection.data || {};
                    rejection.data.error = MSG_NOT_ALLOWED;
                }
                return $q.reject(rejection);
            }
        };
    }

    securityInterceptor.$inject = ['$q', '$log', '$injector', '$rootScope'];
    angular.module('jgood').factory('jg.securityInterceptor', securityInterceptor);


}());
/**
 * Resolves place holders in request urls via webProperties.
 * Note that the 'webProperties' object is filled with the parameters prefixed with '_web_' during gradle build.
 * @author Ramazan KARAKAYA
 */
(function () {
    function requestRetryInterceptor(webProperties) {

        function resolvePlaceHolders(str) {
            str = str.replace(/{(.*?)}/gi, function (a, variable) {
                return webProperties[variable];
            });

            return str;
        }

        return {
            request: function (config) {
                config.url = resolvePlaceHolders(config.url);
                return config;
            }
        };
    }

    requestRetryInterceptor.$inject = ['jg.webProperties'];
    angular.module('jgood').factory('jg.urlPlaceHolderInterceptor', requestRetryInterceptor);


}());

/**
 * @author Ramazan Karakaya
 */

angular.module('jgood').provider('jg.resolve', function () {
    var ctrlResolveMap = {};

    this.getForCtrl = function (ctrlName) {
        return ctrlResolveMap[ctrlName];
    };

    this.registerForCtrl = function (ctrlName, prmResolveMap) {
        var resolveMap = ctrlResolveMap[ctrlName];
        if (!resolveMap) {
            ctrlResolveMap[ctrlName] = prmResolveMap;
        } else {
            angular.extend(resolveMap, prmResolveMap);
        }
    };

    this.$get = function () {
        return function (name) {
            return 'xxx ' + name + '!';
        };
    };
});
/**
 * @author Ramazan Karakaya
 */

(function () {
    function errorsFactory() {
        function handleError(response, title, deferred) {
            var body = (response.data && response.data.error && response.data.error.reason) || 'NA';
            if (_.isObject(body)) {
                body = JSON.stringify(body);
            }
            console.error(title, body);
            if (deferred) {
                deferred.reject(response);
            }

        }

        return {
            httpCatch: function (message, deferred) {
                return function (response) {
                    handleError(response, message, deferred);
                };

            }
        };
    }

    errorsFactory.$inject = [];
    angular.module('jgood').factory('jg.errors', errorsFactory);

}());


(function () {
    function popupServiceFactory($uibModal, $q) {
        var okCancelCtrl = ['$scope', '$uibModalInstance', 'params',
                function ($scope, $uibModalInstance, params) {
                    $scope.params = params;
                    $scope.ok = function (result) {
                        $uibModalInstance.close(result);
                        if ($scope.params.fnOk) {
                            $scope.params.fnOk();
                        }
                    };
                    $scope.cancel = function (result) {
                        $uibModalInstance.dismiss(result);
                    };
                }],

            infoDlgCtrl = ['$scope', '$uibModalInstance', 'modelMap',
                function ($scope, $uibModalInstance, modelMap) {
                    if (modelMap) {
                        angular.extend($scope, modelMap);
                    }

                    $scope.ok = function (result) {
                        $uibModalInstance.close(result);
                    };
                }],


            ctrlConfirm = ['$scope', '$uibModalInstance', 'modelMap', 'fnConfirm',
                function ($scope, $uibModalInstance, modelMap, fnConfirm) {
                    if (modelMap) {
                        angular.extend($scope, modelMap);
                    }

                    $scope.confirm = function () {
                        $uibModalInstance.close();
                        fnConfirm();
                    };

                    $scope.cancel = function () {
                        $uibModalInstance.dismiss();
                    };
                }],


            alertCtrl = ['$scope', '$uibModalInstance', 'params',
                function AlertDialogController($scope, $uibModalInstance, params) {
                    $scope.params = params;
                    $scope.close = function () {
                        $uibModalInstance.close();
                    };
                }];

        return {


            alert: function (msgKey, params) {
                var opts = {
                    templateUrl: 'app/common/partial/dialogAlert.html',
                    controller: alertCtrl,
                    resolve: {
                        params: function () {
                            return {
                                msgKey: msgKey,
                                msgParams: params || []
                            }
                        }
                    }
                };
                $uibModal.open(opts);
            },

            confirmDelete: function (itemName, fnOk) {
                var opts = {
                    templateUrl: 'app/common/partial/dialogConfirmDelete.html',
                    controller: okCancelCtrl,
                    resolve: {
                        params: function () {
                            return {
                                itemName: itemName,
                                fnOk: fnOk
                            }
                        }
                    }
                };
                $uibModal.open(opts);
            },

            showFormDialog: function (parentScope, formModels) {
                var modelMap = formModels || {},
                    deferred = $q.defer(),
                    dialogScope = angular.extend(parentScope.$new(), modelMap),
                    ctrl = ['$scope', '$uibModalInstance',
                        function ($scope, $uibModalInstance) {
                            $scope.ok = function (form) {
                                if (form.$valid) {
                                    $uibModalInstance.close();
                                    deferred.resolve();
                                }
                            };

                            $scope.cancel = function () {
                                $uibModalInstance.dismiss();
                                deferred.reject();
                            };
                        }],

                    opts = {
                        templateUrl: 'app/common/partial/formDlg.html',
                        controller: ctrl,
                        scope: dialogScope
                    };

                $uibModal.open(opts);
                return deferred.promise;
            },

            showDialog: function (templateUrl, objParams, controller) {
                var opts = {
                    templateUrl: templateUrl,
                    controller: controller,
                    resolve: {
                        params: function () {
                            return objParams;
                        }
                    }
                };
                $uibModal.open(opts);
            },

            showInfoDialog: function (templateUrl, modelMap) {
                var models = angular.extend({}, modelMap);
                models.partialUrl = templateUrl;

                var opts = {
                    templateUrl: 'ce/app/common/partial/partialInfoDialog.html',
                    controller: infoDlgCtrl,
                    resolve: {
                        modelMap: function () {
                            return models;
                        }
                    }
                };
                $uibModal.open(opts);
            },


            confirmDialog: function (modelMap, fnConfirm) {
                var onConfirm, models;

                if (angular.isFunction(modelMap)) {
                    onConfirm = modelMap;
                    models = {};
                } else {
                    models = modelMap;
                    onConfirm = fnConfirm;
                }


                var opts = {
                    templateUrl: 'app/common/partial/dialogConfirm.html',
                    controller: ctrlConfirm,
                    resolve: {
                        modelMap: function () {
                            return models;
                        },
                        fnConfirm: function () {
                            return onConfirm;
                        }
                    }
                };
                $uibModal.open(opts);
            }



        };
    }

    popupServiceFactory.$inject = ['$uibModal', '$q'];
    angular.module('jgood').factory('jg.popupService', popupServiceFactory);
}());


(function () {
    function i18nService($q, $http) {
        var props = {
            general: {
                login: 'Login',
                ok: 'Ok',
                cancel: 'Cancel',
                warn: {
                    delete_item: 'Are you sure?'
                },
                error: {
                    required: 'This field is required'
                }
            },
            report: {
                send: 'Send Now',
                informedBy: 'Your Name',
                gsm: 'Your Phone Number',
                gsm_h: 'Your phone number is not required but providing this may help us to improve our service',
                text: 'Text',
                address: 'Address',
                address_h: 'Please provide us a complete address'
            }
        };

        function init() {


            var deferred = $q.defer(),
                lang = navigator.language;

            /*
             * FIXME:  browser settings don't actually affect the navigator.language property that is obtained via javascript.
             * seee http://stackoverflow.com/questions/1043339/javascript-for-detecting-browser-language-preference
             * */

            if (lang !== 'en') {
                //load i18n file for this language
                return $http.get('/resources/locales/' + lang + '.json')
                    .then(function (response) {
                        angular.merge(props, response.data || {});
                    }).finally(function () {
                        deferred.resolve();
                    });
            }
            return deferred.promise;

        }

        function replaceParams(string, placeholders) {
            return string.replace(/\((\d+)\)/g, function (a, b) {
                return placeholders[b];
            });
        }

        function translateKey(strKey) {
            var translated, placeholders = [], i, keyParts;
            if (strKey) {
                placeholders = [];

                for (i = 1; i < arguments.length; i++) {
                    if (typeof (arguments[i]) === 'object') {
                        angular.forEach(arguments[i], function (item) {
                            placeholders.push(item);
                        });
                    } else {
                        placeholders.push(arguments[i]);
                    }
                }
                keyParts = strKey.split('.');
                translated = props;
                for (i = 0; i < keyParts.length; i++) {
                    translated = translated[keyParts[i]];
                    if (!translated) {
                        break;
                    }
                }
                if (translated && typeof translated === 'string') {
                    translated = replaceParams(translated, placeholders);
                }
            }
            return translated;
        }


        return {
            init: init,
            translateSafe: function (strKey) {
                var translated = translateKey.apply(this, arguments);
                return translated || strKey;
            },

            translate: function (strKey) {
                return translateKey.apply(this, arguments);
            }

        };
    }

    i18nService.$inject = ['$q', '$http'];
    angular.module('jgood').factory('jg.textsService', i18nService);
}());

(function () {
    "use strict";
    function DashboardCtrl($scope) {
        var x = 1;
    }

    DashboardCtrl.$inject = ['$scope'];
    angular.module('jgood').controller('jg.DashboardCtrl', DashboardCtrl);
}());
(function () {
    "use strict";
    function InformingListCtrl(popupService, informingService, recentItems) {
        this.recentItems = recentItems;

        this.closeInformingAt = function (index) {
            var inf = this.recentItems.list[index];
            informingService.closeInformingById(inf.id).then(function (updated) {
                angular.extend(inf, updated);
            }.bind(this));
        };

        this.deleteInformingAt = function (index) {
            var list = this.recentItems.list,
                inf = list[index];
            popupService.confirmDelete(inf.id, function () {
                informingService.deleteInformingById(inf.id).then(function () {
                    list.splice(index, 1);
                }.bind(this));
            });
        };

        this.canDelete = function (inf) {
            return inf.status === 'CLOSED';
        };

        this.canClose = function (inf) {
            return inf.status === 'NEW';
        };
    }


    function InformingListCtrlResolver(resolveProvider) {
        resolveProvider.registerForCtrl('jg.InformingListCtrl', {
            recentItems: ['$q', 'jg.informingService',
                function ($q, informingService) {
                    return informingService.fetchRecentItems();
                }]
        });
    }

    InformingListCtrl.$inject = ['jg.popupService', 'jg.informingService', 'recentItems'];
    angular.module('jgood').config(['jg.resolveProvider', InformingListCtrlResolver]);
    angular.module('jgood').controller('jg.InformingListCtrl', InformingListCtrl);
}());
(function () {
    "use strict";
    function informingService($q, $http, errorService) {


        return {
            fetchRecentItems: function () {
                var deferred = $q.defer();
                $http.get('{apiPrefix}/informings').then(function (response) {
                    deferred.resolve(response.data);
                }, errorService.httpCatch('Can not list informings', deferred));
                return deferred.promise;
            },

            deleteInformingById: function (id) {
                var deferred = $q.defer();
                $http['delete']('{apiPrefix}/informings/' + id).then(function (response) {
                    deferred.resolve();
                }, errorService.httpCatch('Delete informing failed', deferred));
                return deferred.promise;
            },

            closeInformingById: function (id) {
                var deferred = $q.defer();
                $http.post('{apiPrefix}/informings/' + id + '/close').then(function (response) {
                    deferred.resolve(response.data);
                }, errorService.httpCatch('Close informing failed', deferred));
                return deferred.promise;
            },

            saveInforming: function (inf) {
                var deferred = $q.defer();
                $http.put('{apiPrefix}/informings', inf).then(function (response) {
                    deferred.resolve(response.data);
                }, errorService.httpCatch('Can not save your report', deferred));
                return deferred.promise;
            }
        };
    }

    informingService.$inject = ['$q', '$http', 'jg.errors'];
    angular.module('jgood').factory('jg.informingService', informingService);
}());


(function () {
    "use strict";
    function ReportUsCtrl($state, informingService) {
        this.inf = {};
        this.saveReport = function (infForm) {
            if (infForm.$valid) {
                informingService.saveInforming(this.inf).then(function () {
                    $state.go('index.thankyou');
                });
            }
        };
    }

    ReportUsCtrl.$inject = ['$state', 'jg.informingService'];
    angular.module('jgood').controller('jg.ReportUsCtrl', ReportUsCtrl);
}());
/**
 * authenticationService - service to manage authentication for users
 *
 * @author Ramazan Karakaya
 */
(function () {
    function authenticationService($rootScope, $http, $httpParamSerializer, $q, $state, fnSecurity, $sessionStorage) {


        function setUiUserProfile(profile) {
            $rootScope.username = profile.username;
            fnSecurity.setPermissions(profile.roles);
        }


        if ($sessionStorage.profile) {
            setUiUserProfile($sessionStorage.profile);
        }

        function authenticate(params) {
            var deferred = $q.defer();

            $http({
                method: 'POST',
                url: '/api/login',
                data: $httpParamSerializer(params),
                headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).then(function () {
                    $http.get('/api/user/profile').then(function (prfResponse) {
                        var profile = {username: params.username, roles: prfResponse.data.roles};
                        setUiUserProfile(profile);
                        $sessionStorage.profile = profile;
                        deferred.resolve();
                    }, function (response) {
                        deferred.reject(response.data.error);
                    });

                }, function (response) {
                    deferred.reject(response.data.error);
                });
            return deferred.promise;
        }


        function authenticateUsernamePassword(username, pwd) {
            var config = {
                username: username,
                password: pwd
            };
            return authenticate(config);
        }

        function logout() {

            $http.get('/api/user/logout').then(function () {
                // Clear any state.
                $rootScope.username = null;
                fnSecurity.setPermissions([]);
                $state.go('login');
            });
        }

        return {
            authenticate: authenticateUsernamePassword,
            logout: logout
        };
    }

    authenticationService.$inject = ['$rootScope', '$http', '$httpParamSerializer', '$q', '$state', 'fnSecurity', '$sessionStorage'];
    angular.module('jgood').factory('jg.authService', authenticationService);

}());
/**
 * LoginCtrl - Login Controller, handles username&password authentication
 *
 * @author Ramazan Karakaya
 */
(function () {


    function LoginCtrl($scope, $rootScope, authenticationService, $state) {
        this.credentials = {
            username: 'admin@jgood.com',
            password: '12345'
        };
        this.loginError = null;
        this.loginSubmitted = false;

        this.processSuccessfulAuthentication = function () {
            var afterLogin = $rootScope.afterLogin;
            if (afterLogin && afterLogin.toState) {
                delete $rootScope.afterLogin;
                $state.go(afterLogin.toState, afterLogin.toParams);
            } else {
                $state.go('index.dashboard');
            }
        };

        $scope.login = function () {
            if (this.loginSubmitted) {
                return;
            }

            this.loginError = null;
            this.loginSubmitted = true;

            var username = this.credentials.username,
                pwd = this.credentials.password;

            if (username && pwd) {
                authenticationService.authenticate(username, pwd)
                    .then(function () {
                        this.processSuccessfulAuthentication();
                    }.bind(this)).catch(function () {
                        this.loginError = 'Bad username or password';
                    }.bind(this)).finally(function () {
                        this.loginSubmitted = false;
                    }.bind(this));
            }
        }.bind(this);


    }

    function LoginCtrlResolver(resolveProvider) {
        resolveProvider.registerForCtrl('jg.LoginCtrl', {
            textInit: ['jg.textsService',
                function (textsService) {
                    return textsService.init();
                }],
            checkAlreadyLoggedIn: ['$q', '$state', '$rootScope',
                function ($q, $state, $rootScope) {
                    var deferred = $q.defer();
                    if ($rootScope.username) {
                        deferred.reject(true);
                        $state.go('index.dashboard');
                    } else {
                        // Not logged in.
                        deferred.resolve(true);
                    }
                    return deferred.promise;
                }]
        });
    }

    LoginCtrl.$inject = ['$scope', '$rootScope', 'jg.authService', '$state'];
    angular.module('jgood').config(['jg.resolveProvider', LoginCtrlResolver]);
    angular.module('jgood').controller('jg.LoginCtrl', LoginCtrl);

}());
/**
 * @author Ramazan Karakaya
 */



(function () {
    "use strict";
    function MainCtrl($scope, authService) {

        this.logout = function () {
            authService.logout();
        };

    }


    function MainCtrlResolver(resolveProvider) {
        resolveProvider.registerForCtrl('jg.MainCtrl', {
            preChecks: ['jg.textsService',
                function (textsService) {
                    return textsService.init();
                }]
        });
    }

    MainCtrl.$inject = ['$scope', 'jg.authService'];
    angular.module('jgood')
        .config(['jg.resolveProvider', MainCtrlResolver])
        .controller('jg.MainCtrl', MainCtrl);


}());
/**
 * minimalizaSidebar - Directive for minimalize sidebar
 */
(function () {
    function MinimalizaSidebarCtrl($scope, $timeout) {
        $scope.minimalize = function () {
            $("body").toggleClass("mini-navbar");
            if (!$('body').hasClass('mini-navbar') || $('body').hasClass('body-small')) {
                // Hide menu in order to smoothly turn on when maximize menu
                $('#side-menu').hide();
                // For smoothly turn on menu
                $timeout(function () {
                    $('#side-menu').fadeIn(500);
                }, 100);
            } else if ($('body').hasClass('fixed-sidebar')) {
                $('#side-menu').hide();
                $timeout(function () {
                    $('#side-menu').fadeIn(500);
                }, 300);
            } else {
                // Remove all inline style from jquery fadeIn function to reset menu state
                $('#side-menu').removeAttr('style');
            }
        }
    }

    function minimalizaSidebar() {
        return {
            restrict: 'A',
            template: '<a class="navbar-minimalize minimalize-styl-2 btn btn-primary" href="" ng-click="minimalize()"><i class="fa fa-bars"></i></a>',
            controller: MinimalizaSidebarCtrl
        };
    }

    MinimalizaSidebarCtrl.$inject = ['$scope', '$timeout'];
    angular.module('jgood').directive('minimalizaSidebar', minimalizaSidebar);

}());
/**

 * @author Ramazan Karakaya
 */
(function () {
    "use strict";
    function mainConfig($stateProvider, $urlRouterProvider, resolveProvider, $httpProvider, $compileProvider, $provide, blockUIConfig) {

        // Disable DEBUG for a perfect AngularJS performance!
        $compileProvider.debugInfoEnabled(false);

        $httpProvider.defaults.headers.common["X-Requested-With"] = 'XMLHttpRequest';

        // initialize get if not there
        if (!$httpProvider.defaults.headers.get) {
            $httpProvider.defaults.headers.get = {};
        }

        // Disable ajax request caching
        $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';

        $httpProvider.interceptors.push('jg.urlPlaceHolderInterceptor');
        $httpProvider.interceptors.push('jg.securityInterceptor');

        // Decorate $state to add next state to use in resolver functions.
        $provide.decorator('$state', ['$delegate', '$rootScope', function ($delegate, $rootScope) {
            $rootScope.$on('$stateChangeStart', function (event, state, params) {
                $delegate.next = state;
                $delegate.toParams = params;
            });

            return $delegate;
        }]);

        $urlRouterProvider.otherwise('/login');

        $stateProvider

            .state('index', {
                abstract: true,
                url: "/index",
                templateUrl: "app/modules/main/partial/content.html",
                controller: 'jg.MainCtrl',
                controllerAs: 'ctrl',
                resolve: resolveProvider.getForCtrl('jg.MainCtrl')
            })
            .state('index.dashboard', {
                url: "/dashboard",
                templateUrl: "app/modules/dashboard/partial/dashboard.html",
                data: {pageTitle: 'Dashboard'},
                controller: 'jg.DashboardCtrl'
            })
            .state('index.informings', {
                url: "/informings",
                templateUrl: "app/modules/informing/partial/list.html",
                controllerAs: 'ctrl',
                controller: 'jg.InformingListCtrl',
                resolve: resolveProvider.getForCtrl('jg.InformingListCtrl')

            })
            .state('index.reportus', {
                url: "/reportus",
                templateUrl: "app/modules/informing/partial/reportus.html",
                controllerAs: 'ctrl',
                controller: 'jg.ReportUsCtrl',
                resolve: resolveProvider.getForCtrl('jg.ReportUsCtrl')

            })
            .state('index.thankyou', {
                url: "/thankyou",
                templateUrl: "app/modules/informing/partial/thankyou.html"
            })
            .state('login', {
                url: "/login",
                templateUrl: "app/modules/main/partial/login.html",
                data: {pageTitle: 'Login', specialClass: 'gray-bg'},
                controller: 'jg.LoginCtrl',
                controllerAs: 'ctrl',
                resolve: resolveProvider.getForCtrl('jg.LoginCtrl')
            });
    }

    mainConfig.$inject = ['$stateProvider', '$urlRouterProvider', 'jg.resolveProvider', '$httpProvider', '$compileProvider', '$provide' ];
    angular.module('jgood').config(mainConfig);
}());



(function () {
    "use strict";
    function mainRun($rootScope, $state) {
        $rootScope.$state = $state;
        $rootScope.network = {failure: false};

        var firstChangeSuccess = $rootScope.$on('$stateChangeSuccess', function () {
            $rootScope.isJgLoaded = true;
            firstChangeSuccess();
        });

        $rootScope.$on('jg:LostConnection', function () {
            $rootScope.network.failure = true;
        });

        $rootScope.$on('jg:ConnectionEstablished', function () {
            $rootScope.network.failure = false;
        });
    }

    mainRun.$inject = ['$rootScope', '$state'];
    angular.module('jgood').run(mainRun);
}());


/**
 * Side navigation directive to run metisMenu plugin when the element is ready.
 *
 * @author Ramazan Karakaya
 */
(function () {
    function sideNavigation($timeout) {
        return {
            restrict: 'A',
            link: function (scope, element) {
                // Call the metsiMenu plugin and plug it to sidebar navigation
                $timeout(function () {
                    element.metisMenu();
                });
            }
        };
    }

    sideNavigation.$inject = ['$timeout'];
    angular.module('jgood').directive('sideNavigation', sideNavigation);
}());
